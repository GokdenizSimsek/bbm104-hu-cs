public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world! My name is Gökdeniz ŞİMŞEK. This is my first Java Code that I submit during BBM 104 Spring 2023 Term.");
    }
}